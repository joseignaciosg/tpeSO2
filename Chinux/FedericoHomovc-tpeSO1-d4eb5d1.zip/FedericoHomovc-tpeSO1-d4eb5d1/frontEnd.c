/***
***
***		frontEnd.c
***				Jose Ignacio Galindo
***				Federico Homovc
***				Nicolas Loreti
***			 	     ITBA 2011
***
***/

/***		System includes		***/
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <error.h>

/***		Project Includes		***/
#include "./include/structs.h"
#include "./include/backEnd.h"
#include "./include/api.h"

int
main(int argc, char * argv[])
{
	int status, k = 0;
	pid_t pid, pid2;
	int * pids;
	servADT server;
	comuADT * clients;
	message msg;
	char * string = "hola mundo";

	server = startServer();
	clients = malloc( sizeof(comuADT *)*(argc+1) ); /*poner en el back*/
	clients[0] = connectToServer(server);  /*main client*/

	if (argc<=2)
	{
		printf("Invalid arguments\n");
		return 1;
	}

	switch( pid = fork() ){
		case -1:
			perror("creating map");
			exit(1);
		case 0:
			printf("empieza el mapa\n");
			clients[1] = connectToServer(server);
			execl("map", "map", argv[1], (char *) 0);
			_exit(0);
		default:
			switch(pid2 = fork()){
				case -1:
					perror("creating IO");
					exit(1);
				case 0:
					printf("empieza IO\n");
					clients[2] = connectToServer(server);
					execl("io", "io", (char *) 0);
					_exit(0);
				default:
					pids = malloc(sizeof(int) * (argc-2));
					while(k < argc-2)
					{
						switch( pids[k] = fork() ){
							case -1:
								perror("creating company");
							case 0:
								printf("empieza la company %d\n", k);
								clients[k+3] = connectToServer(server);
								execl("company", "company", argv[k+2], (char *) 0);
								_exit(0);
						}
						k++;
					}
			}
			sleep(1);
			msg.message = string;
			msg.size = strlen(string);
			/*sendMsg(clients[1], &msg, 0);*/
			while (waitpid(pid, &status, WNOHANG) == 0)
			{
				printf("waiting for map to end...\n");
				sleep(1);
			}
			if( WIFEXITED(status) )
			{
				printf("termino el mapa\n");
				kill(pid2, SIGTERM);
				kill(pids[0], SIGTERM);
				endServer(server);
			}
	}

	/*wait(&rv);
	printf("termina el mapa\n");*/

/*	startSimulation();*/
/*	freeResources();*/

	return 0;
}
